function [z]= gravsim(n)       %the input for calling the program is the number of particles n we want in the system
n=2000         %number of particles(stars)
x=zeros(1,n);             %the x positions of the n stars
dx=zeros(1,n);             %the x velocities of the n stars
y=zeros(1,n);                %the y positions of the n stars
dy=zeros(1,n);            %the y velocities of the n stars
S=0.01;                    %   the strength of gravity in the system(or in other words the range of masse)    0.00055
theta=[];

%Placing the n particles:  here I place them in random places in a circle
%with a concentration towards the center by squaring the random rumber,
%which is less than 1. I then give them a veloctiy based on the square root
%of the radius and make it in an orientation perpendicular to the radius.
for i=1:1:n
    theta(i)=2*pi*rand;           
    ra=rand;           %random number (which is usually less than 1)
    r=double(200*ra^(1.6));              %this is the radius of the galaxy (we can change it)
    x(i)=double(r*sin(theta(i)))+1500;                % x position of the ith particle with respect to the center of the system
    y(i)=double(r*cos(theta(i)))+1500;                   %y position of the ith particle with respect to the center of the system
    
    dy(i)=(r^(1/3))*sin(theta(i))*n*S*2;
    dx(i)=-(r^(1/3))*cos(theta(i))*n*S*2;
end

%Finding the sum of the velocities to center the frame

sumdx=sum(dx)/n;
sumdy=sum(dy)/n;
for i=1:1:n
dx(i)=(dx(i)-sumdx)/10;
dy(i)=(dy(i)-sumdy)/10;
end


%Calculating the change in velocity per unit time, d2x and d2y, and
%changing the velocities accordingly.
for t=1:1:20   %here we can change the time t
    tic                             %starts a stopwath timer
    
     e=zeros(3000,3000,3,'uint8');      % data of the image which can be read later by 'image(e)'
    for n1=1:1:n
        for n2=1:1:n
            if n1~=n2
                if n2>n1
                r=sqrt((y(n1)-y(n2))^2+(x(n1)-x(n2))^2);          %distance between particles n1 and n2
                if r<2
                    r=2;
                end
                
                V1=sqrt((dx(n1)*dx(n1))+(dy(n1)*dy(n1)));   %the resultant velocity of the particle n1
                
                V2=sqrt((dx(n2)*dx(n2))+(dy(n2)*dy(n2))); %the resultant velocity of the other particles n2
                
                d2x=(double(-(((x(n2)-x(n1))/(r)^3))))*2;
                d2y=(double(-(((y(n2)-y(n1))/(r)^3))))*2;
                
                if V1>r
                    d2x=(double(-(((x(n2)-x(n1))/(r)^2))));
                   d2y=(double(-(((y(n2)-y(n1))/(r)^2))));
                
                end
                 if V2>r
                    d2x=(double(-(((x(n2)-x(n1))/(r)^2))));
                    d2y=(double(-(((y(n2)-y(n1))/(r)^2))));
                
               end
                
                dx(n1)=dx(n1)+d2x;       %adding the x acceleration d2x to the x velocity dx of particle n1 
                dy(n1)=dy(n1)+d2y;       %adding the y acceleration d2y to the y velocity dy of particle n1
                dx(n2)=dx(n2)-d2x;          %subtracting the x acceleration d2x from the x velocity dx of particle n2
                dy(n2)=dy(n2)-d2y;         %subtracting the y acceleration d2y from  the y velocity dy of particle n2
                end
            end
        end
    end

%Generating image
    for n1=1:1:n
        x(n1)=x(n1)-dx(n1);
        y(n1)=y(n1)-dy(n1);
        if x(n1)<2995
            if x(n1)>5
                if y(n1)>5
                    if y(n1)<2995
                        for h=1:1:5
                            for w=1:1:5
                        e(floor(x(n1)+h),floor(y(n1)+w),:)=255;
                            end
                        end
                    end
                   
                end
            end
        end
    end
      
    
   
     toc               %prints the elapsed time
   
    
    pause(.01)
    image(e)                                %this command will show the image corresponding to image data e
    axis off
    N(:,t)=getframe;                %this will get a frame at each timestep
    
    
end
save gravsim.mat N                 %this will save the images as a movie which can be retrieved by the command 'load gravsim.mat' and can be played by the command 'movie(N)'
 
%Output: final coordinates as input for collide program
z=[x',y',dx',dy'];

