x= [ 10:10^5 ];
y = 0.4474*((x+36514.523) ./ (x+10788.38));
semilogx(x,y);
xlabel(' n( cm^{-3})','FontWeight','bold','color','r');
ylabel( ' [SII] \lambda6716 / [SII] \lambda6731 ','FontWeight','bold','color','r' );
title('Density Diagnostic','FontWeight','bold','FontSize',15,'color','b');