#include <cmath>
#include <iostream>                           
#include <iomanip>
#include<string>
using namespace std;


double Rydberg(double nu, double n, double m, double Z)  // this function of parameters: frequency, upper level, lower level, atomic number, will calculate the Rydberg constant
{   
	double R; //the Rydberg constant
	double c = 3*pow(10,8); //the speed of light
    R = nu/(pow(Z,2)*c*((1/pow(m,2))-(1/pow(n,2)))); //the formulae for Rydberg constant
	return R; //when we call this function in the program with the right parameters, it'll show us the calculated Rydberg constant
}

double frequency(double n, double m, double R,double Z) //this function of parameters: the upper level, lower level, Rydberg constant, atomic number, will calculate the frequency for the previously calculated R
{    
	double nu; //the frequency
	double c = 3*pow(10,8); 
	nu = pow(Z,2)*R * c * ((1/pow(m,2)) - (1/pow(n,2))); //the formula for the frequency
	return nu;  //return the frequency
}

int testofspeed(double speed) //this function will test if the motion is relativistic or non-relativistic
{
	int s; 
    double c = 3*pow(10,8);
  
	if  (abs(speed) < 0.1*c) //here we are comparing the entered speed with the speed of light, it is considered relativistic if it's bigger than 0.1c
   s=1;
    if (abs(speed) > 0.1*c)
   s=0;
return s;
}


double obs_freq_NR(double f, double v) //this function will return the calculated observed frequency for non relativistic motion
{
	double nf;
    double c = 3*pow(10,8);
	nf = f/(1-(v/c)); //the formula for non relativistic doppler frequency
return nf;
}


double obs_freq_R(double f, double v) //this function will return the calculated observed frequency for relativistic motion
{
	double obs;
    double c = 3*pow(10,8);
	obs = f*sqrt((1+(v/c))/(1-(v/c))); //the formula for relativistic doppler frequency
		return obs;
}

double telescope(double t_1, double t_2, double fr) //this function will return the best telescope choice, it compares the resolving power of both.
{
	double z;
	double r_1, r_2; //the two diameters of the telescopes
	double lambda; //the wavelength to be observed with
    double c = 3*pow(10,8);
	lambda = c/fr; //the formula for the wavelength
	r_1 = lambda / t_1; //the reolving power for the first telescope
	r_2 = lambda / t_2; //the resolving power for the second telescope

	if (r_1 > r_2) //comparing the two resolving powers
		z=1;
	else
		z=0;
	return z;

}



int main()
{ 
	// Part 1: Calculation of the Rydberg Constant

	cout<<"Part 1: Calculation of the Rydberg Constant\n"<<endl;
	double nu,n,m,R,Z; //here we are initializing all the parameters we are going to use in our program
	double freq,v;
	double d_1, d_2;
	double d, fr;
	string E;

	cout<<"Enter the name of the chemical element under consideration: ";
	cin>>E;
		if (E == "Hydrogen")
			Z=1;
		if(E == "Helium")
			Z=2;

	cout<<"Enter the upper level: ";
	cin>>n;

	cout<<"Enter the lower level: ";
	cin>>m;

    cout<<"Enter the corresponding frequency(in Hz) of recombination from n= "<< n <<" to n= "<< m<<": ";
	cin>>nu;

	R = Rydberg(nu,n,m,Z); //here we are calling the function Rydberg that will calculate the Rydberg constant after we passed the right parameters

	cout <<"The Rydberg constant for the " << E<<" atom is: "<< R<<" m-1"<<"\n"<<endl;


	//part 2: Calculation of any recombination frequency between any two levels for the previously calculated Rydberg constant  

	cout<<"Part 2: Calculation of any recombination frequency between any two levels for the previously calculated Rydberg constant \n"<<endl;

	cout<<"Enter the upper level: ";
	cin>>n;

	cout<<"Enter the lower level: ";
	cin>>m;

	cout<<"The frequency of the transition from n= "<<n<<" to n="<< m<< "is: "<<frequency(n,m,R,Z)<<" Hz"<<"\n" <<endl;


	//part 3: Calculating the observed frequencies due to Doppler Effect 
	
	cout<<"Part 3: Calculating the observed frequencies due to Doppler Effect \n"<<endl;

	cout<< "Enter the proper frequency(in Hz): "; //the non shifted frequency
	cin>> freq;

	cout<<"Enter the value of the relative speed in m/s ( put positive sign if the source is approaching and negative if it's receding\n): ";
	cin>>v;

	int r;
	r = testofspeed(v); //we are calling the function that will see if the motion is relativistic or not

		if (r==1) //if the speed is non relativistic
			cout<<"The observed frequency is "<< obs_freq_NR(freq,v)<<" Hz \n"<<endl; //we called the function that calculates the observed frequency for non-relativistic motion

		if (r==0) // if the speed is relativistic
			cout<<"The observed frequency is "<< obs_freq_R(freq,v)<<" Hz \n"<<endl; //we called the function that calculates the observed frequency for relativistic motion


	//part 4: Which telescope we have to go for to map a specific radiation emanating from an external galaxy??

		cout<<" part 4: Which telescope we have to go for to map a specific radiation emanating from an external galaxy??\n"<<endl;

		cout<<"Enter the frequency(in Hz) of radiation aimed to be observed by the two telescopes: ";
		cin>>fr;

		cout<<"Enter the diameter(in m) of the first telescope's lens or mirror: ";
		cin>>d_1;

		cout<<"Enter the diameter(in m) of the second telescope's lens or mirror: ";
		cin>>d_2;
	
		d = telescope(d_1, d_2, fr); //we called the function that will compare between the two resolving powers

			if (d==1)
				cout<<" Go for the telescope of diameter "<< d_2<<" m\n";
		    else
				cout<<"Go for the telescope of diameter "<< d_1<<" m\n";

		   
return 0;
}