
%this script is for adjusting the M92 HR diagram with the data points of
%Hipparcos, we have to change the value of n until we get two fitted curves


errorbar(B_V_0c,M_vc,EMv,'.');
xlabel('(B-V)_0');
ylabel('M_v');
title('Hipparcos and M92 HRD fitting')

hold on;
plot(B_V_m92_c ,V_m92_c - n ,'r+' )             %change n until we get two fitted curves
set(gca,'YDir','reverse');
hold off;

%Explanation:
%so i have used this script to overplot the two curves, changing everytime
%the value of n until i get two fitted curves(data points of the HR of M92
%that are within the error bars of those of Hipparcos sample are maximum).
%the best fit was obtained for n = 14.6, calculating the distance we obtain
% d = 8.3 kpc.
%when running this script (after we try n), we will get the two plots
%of Hipparcus and M92 HR diagrams overplotted on each other.

