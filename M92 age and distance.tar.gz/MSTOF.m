                                                              %Main Sequence turn off point fitting:

%in this script we are going to approximate the B-V value for the main
%sequence turn off point for M92 HRD with the corresponding apparent magnitude m_V.
%by examining the M92 HRD diagram we can approximate this point by the
%following coordinates:
% B-V = 0.38
% m_V = 18.3
%for that B-V = 0.38 we will find the corresponding absolute magnitude in
%Hipparcos HRD by interpolating the data points, and then using the distance modulus equation, we can find
%the distance.

 
z = [0.389  0.4150  0.4260  0.4330   0.4360 0.4370  0.449   0.4590 ];             %color indices where we want to interpolate (around the turn off point)
i = interp1(B_V_0c,M_vc,z,'spline');                   %since we have scattered data we had to interpolate
plot(z,i);
hold on;
errorbar(B_V_0c,M_vc,EMv,'r+');
hold off;
xlabel('B-V');
ylabel('Mv');
title('interpolation of Hipparcos data');
set(gca,'YDir','reverse');
Mv = polyval(i,0.38);                   %here we are finding the M_V corresponding to B-V = 0.38

%we wen run the script we will obtain the plot of Hipparcos after interpolation, and when we type 'Mv' in the main window, we will
%obtain 8.0309
% we have then for the main sequence turn off point of M92 HR diagram: Mv = 8.0309
%and since mv = 18.5 so the distance is calculated by
% mv - Mv = 5log10(d) - 5, we get d = 11 kpc
