
% NOTE: THIS SCRIPT HAS TO BE OPENED AND RUN FIRST, BECAUSE I HAVE 3 OTHER
% SCRIPTS IN DIFFERENT m. FILES IN WHICH I HAVE USED THE DATA CONTAINED IN
% THIS SCRIPT.                              

                                                  % Hipparcus Stars
                    
H = importdata('hipparcos.txt');           %H will read all the data in the txt file 'hipparcos.txt' 
V = H(:,2);                                          % apparent magnitudes
deltaV = H(:,3) ;                                      %V error
deltapi = H(:,5) ;                       %parallax error
pi = H(:,4);                                                % parallaxes
B_V = H(:,6);                               % color indices
deltaB_V = H(:,7) ;                        %color index error
E_bv = H(:,8);                                                % color excess
delta = H(:,10);                                             % correction of metallicity
bin = H(:,11);                                                             % binarity of stars

V_0 = [];                                                                            % magnitudes corrected for extinction
M_v = [];                                                                                         %absolute magnitudes
B_V_0 = [];                                                                       %color indices corrected for extinction
B_V_0c = [];                                                                        %color indices corrected for metallicity
M_vc = [];                       %absolute magnitudes corrected for binarity
EMv = [];                                %Hipparcos Mv error 

EMv = deltaV + 5*0.434*(deltapi ./ pi);             %we used the distance modulus equation to find the error on Mv

V_0 = V - 3.1*E_bv;                                     %applying the correction for extinction                             
M_v = V_0 + 5*log10(0.001*pi) +5;                     %finding Mv
B_V_0 = B_V - (4.1-3.1)*E_bv;                            %correction for extinction of color indices
B_V_0c = B_V_0 + delta;                                     %correction for metallicity of color indices

for k = [1:17]    
    
    if bin(k,1) == 1                        %if the stars are not binaries(their bin is equal to 1 in the bin column), Mv is not corrected
       M_vc(k,1) = M_v(k,1);
    elseif bin(k,1)==2                   %if the stars are binaries, Mv is corrected for binarity
          M_vc(k,1) = M_v(k,1) + 0.375;
    end
    
end


 

                                                                                        %M92 stars
                                                                                        
                                
 M = importdata('m92moy.txt') ;          %all the data of M92 stars are in 'm92moy.txt'
 V_m92_c =[];                            %apparent magnitudes corrected for extinction
 B_V_m92_c = [];                  %color indices corrected for extinction 
V_m92 = M(:,1);
B_V_m92 = M(:,2);
V_m92_c = V_m92 - 3.1*0.02;                            %correction for extinction of apparent magnitudes
B_V_m92_c = B_V_m92 -(4.1 - 3.1)*0.02;               %correction for extinction of color indices


                                                     
                                                                                   %plotting the two HR digrams of M92(mv vs B-V) & Hipparcus(Mv vs B-V)

         % HRD of Hipparcus                                                                                     
subplot(1,2,1);
errorbar(B_V_0c,M_vc,EMv,'.');
xlabel('(B-V)_0');
ylabel('M_v');
title('Hipparcus HR')

set(gca,'YDir','reverse');       %here we reversed the y axis so the magnitudes will be increasing downward

 

        %HRD of M92
subplot(1,2,2);
plot(B_V_m92_c ,V_m92_c,'r+' )
xlabel('(B-V)_0');
ylabel('m_v');
title('M92 HR')
set(gca,'YDir','reverse')




                       
 


                              