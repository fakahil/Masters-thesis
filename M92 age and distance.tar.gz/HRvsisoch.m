
                                     %first we make sure that we are in the
                                     %directory containing the dat.files
                                     %(padova), otherwise it will give us
                                     %an error
                              

Mv = [];                                               %the absolute magnitudes for M92 data points
 
Mv =  V_m92_c -5*log10(8300) +5;         %distance modulus equation to calculate the absolute magnitudes using the distance derived from the first method (d = 8.3 kpc)

t = load('isoc_z0001_m.dat');          %here we are loading the isochrones dat files (everytime we change the value of m which corresponds to log10(age), eg: 6.50, 6.55....8.70...etc) )
 M = t(:,6);                                                         %column 6 of each file contain the absolute magnitudes
BV = t(:,7);                                                         %column 7 of each file contain the color index

plot(B_V_m92_c,Mv,'r+');                               %plotting the HRD of M92 (M_V vs B-V)

hold on;
plot(BV,M,'.');                                                    %overplotting the HRD for the isochrones 
set(gca,'YDir','reverse');
 xlabel('B-V');
ylabel('Mv');
legend('M92 HR','isochm');                          %everytime we load the files, we change the legend of course by changing the value of m which corresponds as we said to log10(age)

